﻿=== Shiren The Wanderer Cursor Set ===

By: Kana

Download: http://www.rw-designer.com/cursor-set/shiren-the-wanderer

Author's description:

A set inspired by Shiren The Wanderer video games

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.